create table Registration(FName varchar(40) NOT NULL,LName varchar(40) NOT NULL,Address varchar(100) NOT NULL,Roll varchar(20) NOT NULL,College varchar(40) NOT NULL,Qualification varchar(40) NOT NULL,Dob varchar(40) NOT NULL,Email varchar(40) NOT NULL,Phone varchar(40) NOT NULL,Password varchar(40) NOT NULL, PRIMARY KEY(FName));


create table Login(username varchar(40) NOT NULL,Password varchar(40) NOT NULL, PRIMARY KEY(username));